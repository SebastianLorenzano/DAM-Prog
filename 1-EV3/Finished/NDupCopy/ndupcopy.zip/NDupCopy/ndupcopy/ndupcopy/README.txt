## ENGLISH ## 

To use this script, the only thing you need is give it a json.
If it is executed without giving it one, it will use a json that is stored in the solution by default.

## [ESPAÑOL] ##

Para usar este script, lo unico que necesitas es pasarle un json. 
Si se ejecuta sin pasarle un json, utilizara el json por defecto, que es el que se encuentra en la solución.
