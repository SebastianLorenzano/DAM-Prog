﻿using System.Text.Json;
using System.Text.Json.Nodes;

namespace ndupcopy
{
    public class Program
    {
        static void Main(string[] args)
        {

            NDupCopy.CreateAndRun(args);
        }

    }
}
