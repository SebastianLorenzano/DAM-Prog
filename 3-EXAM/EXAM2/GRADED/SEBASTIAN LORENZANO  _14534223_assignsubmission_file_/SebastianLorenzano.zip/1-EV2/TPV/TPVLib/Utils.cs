﻿namespace TPVLib
{
    public class Utils<T>
    {
        public static void RemoveElementFromArray(T[] array, T element)
        {
            List<string> list;
        }
    }

}
