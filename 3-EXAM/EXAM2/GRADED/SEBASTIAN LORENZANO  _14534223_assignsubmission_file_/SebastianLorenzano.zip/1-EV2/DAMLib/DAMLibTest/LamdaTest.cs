﻿using System;
using System.Runtime.CompilerServices;
using System.Security.Cryptography.X509Certificates;

namespace DAMLibTest
{
    public class LamdaTest
    {
        static void Main(string[] args)
        {
            List<string> list = new List<string>();





        }


}

    }
}
