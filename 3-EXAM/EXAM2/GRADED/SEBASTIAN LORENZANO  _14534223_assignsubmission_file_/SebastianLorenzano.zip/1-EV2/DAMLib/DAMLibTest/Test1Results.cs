﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAMLibTest
{
    public class Test1Results

    {

        public bool Empty1 { get; set; }

        public int Count1 { get; set; }

        public bool EmptyJuan { get; set; }

        public int CountJuan { get; set; }

        public bool ContainsJuan { get; set; }

        public bool EmptyJuan2 { get; set; }

        public int CountJuan2 { get; set; }

        public bool ContainsJuan2 { get; set; }

        public bool EmptyAna { get; set; }

        public int CountAna { get; set; }

        public bool ContainsAna2 { get; set; }

        public bool EmptyAna2 { get; set; }

        public int CountAna2 { get; set; }

        public bool ContainsAna { get; set; }

    }
}



    // Test de caja blanca

  